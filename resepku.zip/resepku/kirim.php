<?php
include 'process.php';
function lesgo($namafile){
    $x = fopen($namafile, "r");
    while (!feof($x)){
        $data = fgets($x);
        $query = "INSERT INTO bahan VALUES (NULL, '$data'";
        mysqli_query(connect(), $query);
    }
}
// echo fgets($sayur);
// echo fread($sayur, filesize("sayur.md"));

$buah = fopen("buah.md", "r");
// echo fread($buah, filesize("buah.md"));

$bumbu = fopen("bumbu.md", "r");
// echo fread($bumbu, filesize("bumbu.md"));

// for ($bumbu as $dat){
//     echo $dat;
//     echo "<br>";
// }


if(cek_data_get('dor') == "Kirim"){
    lesgo("sayur.md");
}



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <!-- kalo ga method apapun jadi get -->
    <form action="">
        <input type="submit" nama="dor" value="Kirim">
    </form>
</body>
</html>